Set the path to this file and run the triangulation.py file

python triangulation.py